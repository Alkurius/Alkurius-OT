
local amount = 1  --Add 1 TC


function onUse(cid, item, fromPosition, itemEx, toPosition)
	player = Player(cid) 
	if not isPlayer(player) then
	return false
   end
	
	player:sendTextMessage(MESSAGE_STATUS_DEFAULT,'Change 1 TC')   
	accountId = player:getAccountId()	
	db.query("UPDATE `accounts` SET `coins` = `coins` + " .. amount .. " WHERE `id` = " .. accountId)
	
	
	Item(item.uid):remove(1)
	fromPosition:sendMagicEffect(CONST_ME_GIFT_WRAPS)
	return true
end

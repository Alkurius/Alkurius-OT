function onUse(cid, item, fromPosition, itemEx, toPosition)
	item:getPosition():sendMagicEffect(175)
	return true
end

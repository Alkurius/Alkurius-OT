dofile('data/lib/quests/theirMastersVoice.lua')

function onUse(player, item, fromPosition, target, toPosition, isHotkey)
    return Gobbler_onUse(player, item, fromPosition, target, toPosition, isHotkey)
end

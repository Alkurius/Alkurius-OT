local feyristStart = { x = 32973, y = 32225, z = 7} -- top left corner
local paymentItem = 2149 -- small saphire 
local positionAfterEnchantment = Position(33539,32209, 7)

function onUse(creature, item, position, fromPosition, pos, target, toPosition)

	local player = creature:getPlayer()

	if not player then
		return
	end

	if player:getItemCount(paymentItem) >= 1  then
	    player:removeItem(paymentItem, 1)
		player:addItem(7759, 1)
		return true
	end

end

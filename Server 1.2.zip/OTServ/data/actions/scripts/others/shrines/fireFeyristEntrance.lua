local paymentItem = 2147 -- small ruby 7760
local positionAfterEnchantment = Position(33586,32263, 7)


function onUse(player, item, fromPosition, target, toPosition, isHotkey)

    if player:getItemCount(paymentItem) >= 1 then
	    player:removeItem(paymentItem, 1)
		player:addItem(7760, 1)
		return true
	end
	
	return false --
end
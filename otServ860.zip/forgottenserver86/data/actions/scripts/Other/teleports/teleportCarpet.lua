
function onUse(player, item, fromPosition, target, toPosition, isHotkey)
	player:teleportTo(Position(32498, 32314, 8), false)
	return true
end

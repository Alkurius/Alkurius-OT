local lavaHole = {388}
local Mushroom = {4184}


function onUse(player, item, fromPosition, target, toPosition, isHotkey)
	if isInArray(lavaHole, target.itemid) and player:removeItem(2565, 1) then		
		player:addItem(8204, 1)
		player:addItem(7247, 1)
		return true
	end
	if isInArray(Mushroom, target.itemid) then		
		player:addItem(7251, 1)
		return true
	end
	
end

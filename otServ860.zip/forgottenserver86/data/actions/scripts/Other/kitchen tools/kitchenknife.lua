function onUse(player, item, fromPosition, target, toPosition, isHotkey)
	player:say(player:getStorageValue(Storage.DjinnWar.MaridFaction.Mission03), TALKTYPE_MONSTER_SAY)
	player:say(Storage.DjinnWar.MaridFaction.Mission03, TALKTYPE_MONSTER_SAY)
	return onUseKitchenKnife(player, item, fromPosition, target, toPosition, isHotkey)
end

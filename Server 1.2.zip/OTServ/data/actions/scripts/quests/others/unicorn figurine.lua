function onUse(player, item, fromPosition, target, toPosition, isHotkey)
	if player:getStorageValue(9902) == 1 then
		return false
	end

	doCreatureSay(player, "Congratulations, you have completed the quest", TALKTYPE_ORANGE_1)
	player:addItem(34692, 1)
		
	return true
end
